# Define a function `having_fun` that prints "Functions are FUN!".

# Define a function `thirty_seven` that prints the sum of 18 and 19.


# Call the two functions you've defined so far.


# Define a function `hello` that takes in a string parameter and prints the parameter variable.


# Call your `hello` function.


# Define a function `user_input` that asks the user "What is your name?" and stores it in a variable called `user_name` and print the user's name.


# Call your `user_input` function.


# Define a function `good_day` that creates a input dialogue asking the user "Are you having a nice day?" and prints the response.


# Call your `good_day` function.


# Define a function `average` that calculates the average between two parameters and returns the average.


# Call the `average` function and assign to a variable `calculated_average`.

