# Define a function `calculate` that takes in two numbers and adds, subtracts, multiplies, or divides the two numbers.

    # Create a variable `result` and set it to 0.


    # Prompt the user "What do you want to do: Add, Subtract, Multiply or Divide?" and assign the answer to a variable `choice`.


    # Create an if-else statement to perform the proper calculation with the two parameters based on the user's `choice`.











    # Return the calculated `result` variable.


# Call the `calculate` function and print the results.

