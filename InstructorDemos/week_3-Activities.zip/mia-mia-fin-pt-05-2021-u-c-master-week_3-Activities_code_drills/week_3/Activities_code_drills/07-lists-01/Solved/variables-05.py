# Create a list, `list_1`,  with `0`, `1`, `2`, `3` as values.
list_1 = [0, 1, 2, 3]

# Create a list, `list_2` with `4`, `5`, `6`, `7` as values.
list_2 = [4, 5, 6, 7]

# Create a list, `list_3` with `8`, `9`, `10`, `11` as values.
list_3 = [8, 9, 10, 11]

# Create a list, `list_4` with `12`, `13`, `14`, `15` as values.
list_4 = [12, 13, 14, 15]

# Print the 3rd index of `list_1`.
print(list_1[2])

# Print the 1st index of `list_2`.
print(list_2[0])

# Print the 2nd index of `list_3`.
print(list_3[1])

# Print the 4th index of `list_4`.
print(list_4[3])
