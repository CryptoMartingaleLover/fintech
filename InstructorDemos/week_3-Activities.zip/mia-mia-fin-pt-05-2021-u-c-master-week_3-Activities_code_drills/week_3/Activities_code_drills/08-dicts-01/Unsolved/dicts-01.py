
# san_francisco = {
#     "west_coast": True,
#     "has_multiple_bridges": True,
#     "known_for_pizza": False,
#     "coastal": True,
#     "snows": False,
#     "very_hot": False,
#     "mayor": "London Breed",
#     "state": "California",
#     "country": "USA",
#     "best_food": "burritos",
#     "sports_teams": ["Giants", "Warriors", "Forty-Niners"],
#     "tallest_building": "SalesForce Building",
#     "population": 884363,
#     "city_size": "large",
#     "median_house_price": 1610000,
#     "famous_residents": ["Maya Angelou", "Robert Frost", "Carlos Santana"],
#     "homeless_pop": 1150,
#     "political_leaning": "Democrat",
#     "notable_attractions": ["Alcatraz", "Golden Gate Bridge", "Fisherman's Wharf"],
#     "natural_disasters": ["Earthquakes"],
# }

# Re-create the content of the commented out `san_francisco` dictionary by using bracket notation to manually add each of the key-value pairs (including nested objects).























# Print the manually modified `san_francisco` dictionary and confirm the contents match the commented out version.
